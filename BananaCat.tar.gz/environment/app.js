// Says that the project will need the Express library
var express = require("express");
// Create the express() object.
var app = express();

// TODO: Put MySQL dependencies here. 
var mysql = require('mysql');

var connection = mysql.createConnection({
   host: 'bananacat.c7dnoyrsskf4.us-west-1.rds.amazonaws.com',
   port: '3306',
   user: 'BananaCat362',
   password: 'catcpsc362',
   database: 'JonathanBedoy'
});
var a = "SELECT * FROM";
var b = "Account";
a = a+b;
connection.connect(function(err) {
   if(err) {
      console.error('Database connection failed: ' + err.stack);
   }
   console.log('Connected to database');
   if (err) throw err;
});

connection.query("a", function (err, result, fields) {
    if (err) throw err;
    console.log(result[1].Username);
    
    
  });


// Set the view engine to EJS. This means we're loading dynamic HTML files through EJS.
app.set('view engine', 'ejs');

// Renders the home/index page.
app.get('/', function(req, res){ 
   res.render('pages/index');
});

app.get('/products', function(req, res){
   res.render('pages/products');
});

app.get('/apparel', function(req, res){
   res.render('pages/apparel'); 
});

app.get('/register', function(req, res){
   res.render('pages/register');
});

app.get('/myaccount', function(req, res){
   res.render('pages/myaccount');
});

app.get('/booksandmanga', function(req, res){
   res.render('pages/booksandmanga');
});

app.get('/accessories', function(req, res){
   res.render('pages/accessories');
});

// Starts the server!
app.listen(process.env.PORT, process.env.IP, function(){
   console.log("Server has started!");
});